# Keyboard Simpel Riz

Source project for the Android keyboard app.

## Update 1.1
- Adds a dedicated `?` action on the main keyboard's bottom action row.
- Removes the old long-press `.` shortcut for `?`.
- Updates the emoji page with 🍑 in the top row center and a `?123` navigation action.
- Changes the Custom page navigation action to `?123`.
- Limits clipboard history to three entries and keeps the delete key in the lower-right grid position.
- Adds a Clipboard shortcut to the main keyboard action row.

Application ID: `com.riz.keyboard.simple`
Version: `1.1` (versionCode 2)

This ZIP contains Android Studio source code. It is not a compiled APK. Build with Android Studio/Gradle and configure release signing using the repository's GitHub Actions secrets or local signing environment variables.

## Update 1.2 - Photo keyboard background
- Adds gallery photo selection using Android's document picker and persists read access to the selected image.
- Adds independent 0-100% photo darkness and key transparency controls.
- Adds a reset action to return to the built-in theme background.
- Applies the photo behind all keyboard pages while retaining existing key layouts and actions.

After changing the photo or sliders, reopen the keyboard to refresh its appearance.
