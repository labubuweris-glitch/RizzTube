package com.lodaya.jumbokeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONArray

class MainActivity : Activity() {
    companion object {
        private const val KEY_PHOTO_URI = "keyboard_photo_uri"
        private const val KEY_PHOTO_DARKNESS = "keyboard_photo_darkness"
        private const val KEY_KEY_TRANSPARENCY = "keyboard_key_transparency"
    }
    private val prefs by lazy { getSharedPreferences(JumboInputMethodService.PREFS, Context.MODE_PRIVATE) }
    private val themes = listOf(
        "maroon" to "Marun",
        "black" to "Hitam elegan",
        "green" to "Hijau",
        "blue" to "Biru laut",
        "light" to "Terang",
        "purple" to "Ungu",
        "orange" to "Oranye",
        "pink" to "Merah muda"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(Color.rgb(18, 24, 39))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(TextView(this).apply {
            text = "Keyboard Simpel Riz"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        page.addView(TextView(this).apply {
            text = "Keyboard sederhana, ringan, dengan clipboard dan angka di atas huruf."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(18))
        })

        val enable = Button(this).apply {
            text = "1. Aktifkan Keyboard Simpel Riz"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        page.addView(enable, matchWrap())

        val choose = Button(this).apply {
            text = "2. Pilih Keyboard Simpel Riz"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        page.addView(choose, matchWrap())

        page.addView(TextView(this).apply {
            text = "Tema warna"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(22), 0, dp(8))
        })

        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val current = prefs.getString(JumboInputMethodService.KEY_THEME, "light") ?: "light"
        var checkedId = -1
        themes.forEach { (key, label) ->
            val radio = RadioButton(this).apply {
                id = android.view.View.generateViewId()
                text = label
                textSize = 17f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(100, 180, 255))
                if (key == current) checkedId = id
                setOnClickListener {
                    prefs.edit().putString(JumboInputMethodService.KEY_THEME, key).apply()
                }
            }
            group.addView(radio)
        }
        if (checkedId != -1) group.check(checkedId)
        page.addView(group)

        page.addView(TextView(this).apply {
            text = "Tinggi Keyboard"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(24), 0, dp(8))
        })
        page.addView(TextView(this).apply {
            text = "Atur tinggi tombol keyboard sesuai kenyamanan mengetik."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(6))
        })

        val heightGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val currentHeight = prefs.getString(JumboInputMethodService.KEY_KEYBOARD_HEIGHT, "high") ?: "high"
        var checkedHeightId = -1
        listOf(
            "high" to "Tinggi (bawaan)",
            "medium" to "Sedang",
            "low" to "Rendah"
        ).forEach { (key, label) ->
            val radio = RadioButton(this).apply {
                id = android.view.View.generateViewId()
                text = label
                textSize = 17f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(100, 180, 255))
                if (key == currentHeight) checkedHeightId = id
                setOnClickListener {
                    prefs.edit().putString(JumboInputMethodService.KEY_KEYBOARD_HEIGHT, key).apply()
                    android.widget.Toast.makeText(
                        this@MainActivity,
                        "Tinggi keyboard disimpan. Buka kembali keyboard agar perubahan diterapkan.",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            }
            heightGroup.addView(radio)
        }
        if (checkedHeightId != -1) heightGroup.check(checkedHeightId)
        page.addView(heightGroup)

        page.addView(TextView(this).apply {
            text = "Latar Belakang Foto"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(24), 0, dp(8))
        })
        page.addView(TextView(this).apply {
            text = "Pilih foto dari galeri. Foto akan memenuhi area keyboard dan pilihanmu tersimpan di perangkat."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(8))
        })
        page.addView(Button(this).apply {
            text = "Pilih Foto dari Galeri"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, 4102)
            }
        }, matchWrap())
        page.addView(Button(this).apply {
            text = "Reset Foto ke Tema Bawaan"
            setOnClickListener {
                prefs.edit().remove(KEY_PHOTO_URI).apply()
                render()
                android.widget.Toast.makeText(this@MainActivity, "Foto latar direset ke tema bawaan", android.widget.Toast.LENGTH_SHORT).show()
            }
        }, matchWrap())

        fun addSettingSlider(title: String, key: String, defaultValue: Int, suffix: String) {
            val label = TextView(this).apply {
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(0, dp(10), 0, dp(2))
            }
            val seek = SeekBar(this).apply {
                max = 100
                progress = prefs.getInt(key, defaultValue).coerceIn(0, 100)
                progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(100, 180, 255))
                thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(100, 180, 255))
            }
            fun updateLabel(value: Int) { label.text = "$title: $value$suffix" }
            updateLabel(seek.progress)
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    updateLabel(value)
                    if (fromUser) prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
            page.addView(label)
            page.addView(seek, matchWrap())
        }
        addSettingSlider("Kegelapan foto", KEY_PHOTO_DARKNESS, 25, "%")
        addSettingSlider("Transparansi tombol", KEY_KEY_TRANSPARENCY, 28, "%")
        page.addView(TextView(this).apply {
            text = "Atur transparansi tombol ke 0% agar tombol tetap pekat, atau naikkan agar foto terlihat melalui tombol. Kegelapan foto diatur terpisah. Buka ulang keyboard untuk menerapkan perubahan."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(12))
        })

        page.addView(TextView(this).apply {
            text = "Nama & Teks Custom Clipboard"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(24), 0, dp(6))
        })
        page.addView(TextView(this).apply {
            text = "Tiga tombol bawaan (Brush212, 110188, 081094) selalu tersedia. Kamu bisa menyimpan maksimal 6 Custom buatan sendiri. Riwayat Clipboard menyimpan maksimal 8 teks terbaru."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(10))
        })
        val customFields = mutableListOf<EditText>()
        val customList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun addCustomField(value: String = "") {
            if (customFields.size >= 6) return
            val edit = EditText(this).apply {
                setSingleLine(false)
                minLines = 1
                maxLines = 2
                textSize = 15f
                setTextColor(Color.WHITE)
                setHintTextColor(Color.LTGRAY)
                hint = "Teks custom ${customFields.size + 1}"
                setText(value)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(31, 39, 57))
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), Color.rgb(75, 88, 112))
                }
            }
            customFields.add(edit)
            customList.addView(edit, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
            ).apply { bottomMargin = dp(6) })
        }

        val packed = prefs.getString("custom_clip_texts", null)
        val existingCustoms = if (packed != null) {
            try {
                val array = JSONArray(packed)
                MutableList(array.length()) { i -> array.optString(i) }.filter { it.isNotBlank() }.take(6)
            } catch (_: Exception) { emptyList() }
        } else {
            (0 until 6).map { prefs.getString("custom_clip_text_$it", "") ?: "" }.filter { it.isNotBlank() }
        }
        existingCustoms.forEach { addCustomField(it) }
        if (customFields.isEmpty()) addCustomField()
        page.addView(customList)
        val addCustomButton = Button(this).apply {
            text = "+ Tambah kolom Custom"
            setOnClickListener {
                if (customFields.size < 6) {
                    addCustomField()
                    isEnabled = customFields.size < 6
                    alpha = if (isEnabled) 1f else 0.5f
                }
            }
        }
        addCustomButton.isEnabled = customFields.size < 6
        addCustomButton.alpha = if (addCustomButton.isEnabled) 1f else 0.5f
        page.addView(addCustomButton, matchWrap())
        page.addView(Button(this).apply {
            text = "− Hapus kolom terakhir"
            setOnClickListener {
                if (customFields.size > 1) {
                    val last = customFields.removeAt(customFields.lastIndex)
                    customList.removeView(last)
                    addCustomButton.isEnabled = true
                    addCustomButton.alpha = 1f
                } else {
                    customFields.firstOrNull()?.setText("")
                }
            }
        }, matchWrap())
        page.addView(Button(this).apply {
            text = "Simpan Custom Clipboard"
            setOnClickListener {
                val values = customFields.map { it.text.toString().trim() }.filter { it.isNotBlank() }.take(6)
                val array = JSONArray()
                values.forEach { array.put(it) }
                prefs.edit().putString("custom_clip_texts", array.toString()).apply()
                android.widget.Toast.makeText(
                    this@MainActivity, "${values.size}/6 Custom berhasil disimpan", android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }, matchWrap())

        page.addView(TextView(this).apply {
            text = "Cara memakai"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(22), 0, dp(8))
        })
        page.addView(TextView(this).apply {
            text = "• Tekan Aktifkan Keyboard Simpel Riz, lalu aktifkan di pengaturan Android.\n\n• Tekan Pilih Keyboard Simpel Riz dan pilih keyboard ini.\n\n• Tombol 😊 membuka emoji; tombol ALT membuka simbol tambahan.\n\n• Tombol 📋 menampilkan teks clipboard saat ini dan riwayat yang pernah dibuka melalui tombol tersebut.\n\n• Pilih tema warna di halaman ini, lalu buka kembali keyboard."
            textSize = 16f
            setTextColor(Color.LTGRAY)
        })
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4102 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
                prefs.edit().putString(KEY_PHOTO_URI, uri.toString()).apply()
                android.widget.Toast.makeText(this, "Foto latar berhasil disimpan", android.widget.Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                prefs.edit().putString(KEY_PHOTO_URI, uri.toString()).apply()
                android.widget.Toast.makeText(this, "Foto dipilih. Jika tidak tampil, pilih ulang dari galeri.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
