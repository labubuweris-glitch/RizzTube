package com.lodaya.jumbokeyboard

import android.inputmethodservice.InputMethodService
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.PopupMenu
import android.widget.EditText
import android.widget.PopupWindow
import org.json.JSONArray

class JumboInputMethodService : InputMethodService() {
    companion object {
        const val PREFS = "jumbo_keyboard_settings"
        const val KEY_THEME = "keyboard_theme"
        const val KEY_KEYBOARD_HEIGHT = "keyboard_height"
    }

    private var symbols = false
    private var extendedSymbols = false
    private var emojiMode = false
    private var clipMode = false
    private var customMode = false
    private var clipboardManager: ClipboardManager? = null
    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private var shifted = false
    private var capsLocked = false
    private var lastShiftTapMs = 0L

    private data class Palette(val background: Int, val key: Int, val special: Int, val text: Int)

    private fun palette(): Palette {
        val key = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_THEME, "light") ?: "light"
        return when (key) {
            "black" -> Palette(Color.rgb(15, 17, 22), Color.rgb(48, 51, 59), Color.rgb(76, 80, 91), Color.WHITE)
            "green" -> Palette(Color.rgb(9, 35, 29), Color.rgb(26, 91, 69), Color.rgb(18, 119, 83), Color.WHITE)
            "blue" -> Palette(Color.rgb(12, 28, 48), Color.rgb(36, 77, 112), Color.rgb(30, 104, 157), Color.WHITE)
            "light" -> Palette(Color.rgb(232, 235, 241), Color.rgb(255, 255, 255), Color.rgb(203, 211, 223), Color.rgb(25, 29, 38))
            "purple" -> Palette(Color.rgb(31, 18, 48), Color.rgb(82, 49, 120), Color.rgb(118, 70, 168), Color.WHITE)
            "orange" -> Palette(Color.rgb(48, 27, 12), Color.rgb(135, 73, 25), Color.rgb(190, 102, 31), Color.WHITE)
            "pink" -> Palette(Color.rgb(48, 19, 35), Color.rgb(130, 49, 88), Color.rgb(180, 63, 117), Color.WHITE)
            else -> Palette(Color.rgb(238, 240, 243), Color.WHITE, Color.rgb(220, 224, 230), Color.rgb(30, 34, 40))
        }
    }

    private fun keyboardHeight(base: Int): Int {
        val size = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_KEYBOARD_HEIGHT, "high") ?: "high"
        val scale = when (size) {
            "medium" -> 0.85f
            "low" -> 0.70f
            else -> 1.0f
        }
        return dp((base * scale).toInt())
    }

    private val clipboardHandler = Handler(Looper.getMainLooper())
    private val clipboardReadTask = Runnable { captureCurrentClipboard() }

    override fun onCreate() {
        super.onCreate()
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        initializeDefaultClipboardHistory()
        // Keep the watcher alive for the lifetime of the IME service, not only while
        // the keyboard window is visible. Some apps copy text while the keyboard is hidden.
        startClipboardWatcher()
    }

    override fun onDestroy() {
        stopClipboardWatcher()
        clipboardHandler.removeCallbacks(clipboardReadTask)
        super.onDestroy()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Re-register if Android recreated the input view/service state.
        startClipboardWatcher()
    }

    private fun startClipboardWatcher() {
        val manager = clipboardManager ?: return
        if (clipboardListener != null) return
        val listener = ClipboardManager.OnPrimaryClipChangedListener {
            // A short delay lets Android finish publishing the new ClipData before reading it.
            clipboardHandler.removeCallbacks(clipboardReadTask)
            clipboardHandler.postDelayed(clipboardReadTask, 120L)
        }
        try {
            manager.addPrimaryClipChangedListener(listener)
            clipboardListener = listener
        } catch (_: Exception) {
            clipboardListener = null
        }
    }

    private fun captureCurrentClipboard() {
        val manager = clipboardManager ?: return
        try {
            val clip = manager.primaryClip ?: return
            if (clip.itemCount <= 0) return
            // Save every plain-text item, not just item zero. saveClip handles duplicates.
            for (index in 0 until clip.itemCount) {
                val text = clip.getItemAt(index).coerceToText(this)?.toString() ?: continue
                if (text.isNotBlank()) saveClip(text)
            }
        } catch (_: SecurityException) {
            // Android privacy rules may block reads in some situations; no app can bypass them.
        } catch (_: Exception) { }
    }

    private fun stopClipboardWatcher() {
        val manager = clipboardManager
        val listener = clipboardListener
        if (manager != null && listener != null) {
            try { manager.removePrimaryClipChangedListener(listener) } catch (_: Exception) { }
        }
        clipboardListener = null
    }

    private fun readHistory(): List<String> = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString("clip_history", "").orEmpty().split("\n\u0000\n").filter { it.isNotBlank() }.take(3)

    private fun readPinned(): List<String> = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString("clip_pinned", "").orEmpty().split("\n\u0000\n").filter { it.isNotBlank() }.take(3)

    // Pinned clips always appear first and are kept separate from ordinary history.
    private fun readClips(): List<String> {
        val pinned = readPinned()
        return (pinned + readHistory().filterNot { it in pinned }).take(3)
    }

    private fun readUserCustoms(): MutableList<String> {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val packed = prefs.getString("custom_clip_texts", null)
        if (packed != null) {
            return try {
                val array = JSONArray(packed)
                MutableList(array.length()) { i -> array.optString(i).trim() }.filter { it.isNotBlank() }.take(6).toMutableList()
            } catch (_: Exception) { mutableListOf() }
        }
        // Migrate the six-slot format from older app versions without losing saved texts.
        return (0 until 6).map { i -> prefs.getString("custom_clip_text_$i", "")?.trim().orEmpty() }
            .filter { it.isNotBlank() }.take(6).toMutableList()
    }

    private fun writeUserCustoms(values: List<String>) {
        val packed = JSONArray()
        values.map { it.trim() }.filter { it.isNotBlank() }.take(6).forEach { packed.put(it) }
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("custom_clip_texts", packed.toString()).apply()
    }

    private fun customClipboardTexts(): List<String> = listOf("Brush212", "110188", "081094") + readUserCustoms()

    // Seed the clipboard once for new installs. A real copied text naturally
    // becomes the newest item and pushes these placeholders down the history.
    private fun initializeDefaultClipboardHistory() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("clip_defaults_initialized", false)) return
        if (readHistory().isEmpty() && readPinned().isEmpty()) {
            prefs.edit()
                .putString("clip_history", listOf("Brush212", "110188", "081094").joinToString("\n\u0000\n"))
                .putBoolean("clip_defaults_initialized", true)
                .apply()
        } else {
            // Existing users keep their current history; don't replace it.
            prefs.edit().putBoolean("clip_defaults_initialized", true).apply()
        }
    }

    private fun saveClip(text: String) {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (text in readPinned()) return
        val historyLimit = (3 - readPinned().size).coerceAtLeast(0)
        val updated = (listOf(text) + readHistory().filterNot { it == text }).take(historyLimit)
        prefs.edit().putString("clip_history", updated.joinToString("\n\u0000\n")).apply()
    }

    private fun deleteClip(text: String) {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pinned = readPinned().filterNot { it == text }
        val history = readHistory().filterNot { it == text }
        prefs.edit()
            .putString("clip_pinned", pinned.joinToString("\n\u0000\n"))
            .putString("clip_history", history.joinToString("\n\u0000\n"))
            .apply()
        android.widget.Toast.makeText(this, "Teks dihapus", android.widget.Toast.LENGTH_SHORT).show()
        setInputView(buildKeyboard())
    }

    private fun showClipOptions(text: String, anchor: View) {
        // Use a popup anchored to the keyboard key. An AlertDialog can crash on some
        // Android versions when launched from an InputMethodService window.
        val isPinned = text in readPinned()
        val pinLabel = if (isPinned) "📌 Lepas sematan" else "📌 Sematkan"
        val popup = PopupMenu(anchor.context, anchor)
        popup.menu.add(pinLabel)
        popup.menu.add("🗑️ Hapus teks ini")
        popup.menu.add("⭐ Jadikan Custom")
        popup.menu.add("Batal")
        popup.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                pinLabel -> togglePinnedClip(text)
                "🗑️ Hapus teks ini" -> deleteClip(text)
                "⭐ Jadikan Custom" -> saveAsCustom(text)
                else -> { /* Batal: tutup menu saja. */ }
            }
            true
        }
        popup.show()
    }

    private fun showCustomOptions(index: Int, anchor: View) {
        // Three built-in buttons are protected; only user-created entries are manageable.
        if (index < 3) return
        val userIndex = index - 3
        val values = readUserCustoms()
        if (userIndex !in values.indices) return
        val popup = PopupMenu(anchor.context, anchor)
        popup.menu.add("🗑️ Hapus")
        popup.menu.add("↕️ Pindahkan urutan")
        popup.menu.add("Batal")
        popup.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "🗑️ Hapus" -> {
                    values.removeAt(userIndex)
                    writeUserCustoms(values)
                    android.widget.Toast.makeText(this, "Custom dihapus", android.widget.Toast.LENGTH_SHORT).show()
                    setInputView(buildKeyboard())
                }
                "↕️ Pindahkan urutan" -> showMoveCustom(userIndex, values, anchor)
            }
            true
        }
        popup.show()
    }

    private fun showMoveCustom(index: Int, values: List<String>, anchor: View) {
        val moveMenu = PopupMenu(anchor.context, anchor)
        values.indices.forEach { destination ->
            if (destination != index) moveMenu.menu.add("Posisi ${destination + 1}")
        }
        moveMenu.setOnMenuItemClickListener { item ->
            val destination = item.title.toString().removePrefix("Posisi ").toIntOrNull()?.minus(1) ?: -1
            val updated = readUserCustoms()
            if (index in updated.indices && destination in updated.indices && destination != index) {
                val moved = updated.removeAt(index)
                updated.add(destination, moved)
                writeUserCustoms(updated)
                android.widget.Toast.makeText(this, "Urutan Custom diperbarui", android.widget.Toast.LENGTH_SHORT).show()
                setInputView(buildKeyboard())
            }
            true
        }
        moveMenu.show()
    }

    private fun saveAsCustom(text: String) {
        val value = text.trim()
        if (value.isEmpty()) return

        val saved = readUserCustoms()

        if (value in saved) {
            android.widget.Toast.makeText(this, "Teks ini sudah ada di Custom", android.widget.Toast.LENGTH_SHORT).show()
            return
        }

        if (saved.size >= 6) {
            android.widget.Toast.makeText(this, "Custom sudah penuh (maksimal 6)", android.widget.Toast.LENGTH_SHORT).show()
            return
        }

        saved.add(value)
        writeUserCustoms(saved)
        android.widget.Toast.makeText(this, "Berhasil ditambahkan ke Custom ⭐", android.widget.Toast.LENGTH_SHORT).show()
        customMode = true
        clipMode = true
        setInputView(buildKeyboard())
    }

    private fun togglePinnedClip(text: String) {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pinned = readPinned().toMutableList()
        if (text in pinned) {
            pinned.remove(text)
            val history = (listOf(text) + readHistory().filterNot { it == text }).take((7 - pinned.size).coerceAtLeast(0))
            prefs.edit()
                .putString("clip_pinned", pinned.joinToString("\n\u0000\n"))
                .putString("clip_history", history.joinToString("\n\u0000\n"))
                .apply()
            android.widget.Toast.makeText(this, "Sematan dilepas", android.widget.Toast.LENGTH_SHORT).show()
        } else {
            if (pinned.size >= 8) {
                android.widget.Toast.makeText(this, "Clipboard sudah penuh (maksimal 8)", android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            pinned.add(0, text)
            prefs.edit()
                .putString("clip_pinned", pinned.joinToString("\n\u0000\n"))
                .putString("clip_history", readHistory().filterNot { it == text }.take((7 - pinned.size).coerceAtLeast(0)).joinToString("\n\u0000\n"))
                .apply()
            android.widget.Toast.makeText(this, "Teks disematkan 📌", android.widget.Toast.LENGTH_SHORT).show()
        }
        setInputView(buildKeyboard())
    }

    override fun onCreateInputView(): View = buildKeyboard()

    private fun buildKeyboard(): View {
        val p = palette()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(5), dp(3), dp(5))
            background = keyboardBackground(p.background)
        }

        val clips = readClips()
        val customTexts = customClipboardTexts()
        val rows: List<List<String>> = when {
            clipMode -> {
                // Custom mode is intentionally isolated: show only the ready-made
                // and user-saved custom texts from Settings, never clipboard history.
                val contentRows = if (customMode) {
                    customTexts.chunked(3).mapIndexed { row, values ->
                        values.mapIndexed { col, _ -> "CUSTOM${row * 3 + col}" } +
                            List(3 - values.size) { "" }
                    }
                } else {
                    // Clipboard menampilkan maksimal 3 item.
                    listOf(
                        (1..3).map { index -> if (index <= clips.size) "CLIP$index" else "" }
                    )
                }
                contentRows + if (customMode) {
                    // Custom Teks tidak memiliki fungsi hapus riwayat clipboard.
                    listOf(listOf("ABC", "📋", "spasi", "↵", "⌫"))
                } else {
                    listOf(listOf("ABC", "?123", "spasi", "↵", "⌫"))
                }
            }
            emojiMode -> listOf(
                listOf("😂", "🤣", "🍑", "😍", "🥰"),
                listOf("😁", "😎", "😭", "😡", "🤔"),
                listOf("👍", "👎", "🙏", "👏", "💪"),
                listOf("❤️", "💖", "🔥", "🎉", "✨"),
                listOf("😴", "🤗", "😘", "😅", "⌫"),
                // Gunakan Clipboard di baris emoji; tombol Custom utama sudah ada di baris bawah.
                listOf("ABC", "spasi", "📋", "↵")
            )
            !symbols -> listOf(
                // Simpel Riz: angka satu baris tepat di atas keyboard QWERTY.
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
                listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
                listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"),
                listOf("?123", ",", "spasi", ".", "?", "↵")
            )
            extendedSymbols -> listOf(
                listOf("[", "]", "{", "}", "<", ">"),
                listOf("\\", "|", "~", "^", "°", "€"),
                listOf("£", "¥", "¢", "§", "©", "®"),
                listOf("™", "±", "×", "÷", "≠", "≈"),
                listOf("≤", "≥", "√", "π", "∞", "⌫"),
                listOf("ALT", "ABC", "spasi", "📋", "↵")
            )
            else -> listOf(
                listOf("!", ":", "(", ")", "+"),
                listOf("@", ";", "'", "-", "="),
                listOf("\$", "1", "2", "3", "\""),
                listOf("%", "4", "5", "6", "?"),
                listOf("&", "7", "8", "9", "."),
                listOf("/", "*", "0", "#", "⌫"),
                listOf("ALT", "ABC", "spasi", "↵")
            )
        }

        rows.forEachIndexed { rowIndex, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { label ->
                if (label.isEmpty()) {
                    val spacer = View(this)
                    val spacerLp = LinearLayout.LayoutParams(0, keyboardHeight(if (rowIndex == rows.lastIndex) 52 else 56), 1f)
                    spacerLp.setMargins(dp(2), dp(3), dp(2), dp(3))
                    line.addView(spacer, spacerLp)
                    return@forEach
                }
                // Item Clipboard memakai warna tombol biasa (gelap); tombol fungsi
                // seperti hapus tetap memakai warna khusus (terang).
                val special = label in setOf("⇧", "⌫", "?123", "ABC", "Custom", "ALT", "spasi", "↵", "😊", "🍑", "📋", "🗑", "↩", "🔍", "?")
                val button = Button(this).apply {
                    text = when {
                        label == "spasi" -> ""
                        label == "⇧" && capsLocked -> "⇪"
                        clipMode && label.startsWith("CUSTOM") -> {
                            val index = label.removePrefix("CUSTOM").toIntOrNull() ?: -1
                            val value = customTexts.getOrNull(index).orEmpty()
                            if (value.isBlank()) "＋ Custom" else {
                                val preview = value.replace(Regex("\\s+"), " ").trim()
                                (if (preview.length > 9) preview.take(9) + "…" else preview)
                            }
                        }
                        clipMode && label.startsWith("CLIP") -> {
                            val index = label.removePrefix("CLIP").toIntOrNull()?.minus(1) ?: -1
                            val clipText = clips.getOrNull(index).orEmpty()
                            val preview = clipText.replace(Regex("\\s+"), " ").trim()
                            val shortened = if (preview.length > 10) preview.take(10) + "…" else preview
                            if (shortened.isBlank()) label else (if (clipText in readPinned()) "📌 " else "") + shortened
                        }
                        !symbols && !emojiMode && label.length == 1 && label[0].isLetter() && (shifted || capsLocked) -> label.uppercase()
                        else -> label
                    }
                    textSize = when {
                        label == "spasi" -> 12f
                        clipMode && (label.startsWith("CLIP") || label.startsWith("CUSTOM")) -> 11f
                        label in setOf("?123", "ABC", "Custom", "ALT", "⇧", "⌫", "↵", "😊", "🍑", "📋", "🗑", "↩", "🔍", "?") -> 16f
                        else -> if (emojiMode || label.codePointsCompat() > 1) 22f else 21f
                    }
                    setTextColor(p.text)
                    setTypeface(null, Typeface.BOLD)
                    isAllCaps = false
                    minWidth = 0
                    minimumWidth = 0
                    minHeight = 0
                    minimumHeight = 0
                    stateListAnimator = null
                    background = GradientDrawable().apply {
                        val baseColor = if (special) p.special else p.key
                        val transparency = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                            .getInt("keyboard_key_transparency", 28).coerceIn(0, 100)
                        val fillAlpha = (255 * (100 - transparency) / 100f).toInt()
                        setColor(Color.argb(fillAlpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor)))
                        cornerRadius = dp(5).toFloat()
                        setStroke(dp(1), Color.argb(110, 0, 0, 0))
                    }
                    setPadding(dp(1), 0, dp(1), 0)
                    contentDescription = when (label) {
                        "spasi" -> "Spasi"
                        "⌫" -> "Hapus"
                        "↵" -> "Enter atau baris baru"
                        "😊" -> "Emoji"
                        "📋" -> "Riwayat salinan"
                        "🗑" -> "Hapus riwayat clip"
                        "🔍" -> "Cari"
                        "Custom" -> "Tampilkan teks custom"
                        "↩" -> "Kembali ke keyboard"
                        else -> label
                    }
                    setOnClickListener {
                        animate().cancel()
                        animate().scaleX(0.92f).scaleY(0.92f).alpha(0.82f).setDuration(55)
                            .withEndAction {
                                animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(85).start()
                            }.start()
                        handleKey(label)
                    }

                    if (clipMode && label.startsWith("CUSTOM")) {
                        setOnClickListener {
                            val index = label.removePrefix("CUSTOM").toIntOrNull() ?: -1
                            val value = customTexts.getOrNull(index).orEmpty()
                            if (value.isNotBlank()) currentInputConnection?.commitText(value, 1)
                        }
                    }

                    if (clipMode && label.startsWith("CUSTOM")) {
                        setOnLongClickListener {
                            val index = label.removePrefix("CUSTOM").toIntOrNull() ?: -1
                            showCustomOptions(index, this)
                            true
                        }
                    }

                    if (clipMode && label.startsWith("CLIP")) {
                        setOnLongClickListener {
                            val index = label.removePrefix("CLIP").toIntOrNull()?.minus(1) ?: -1
                            val clip = readClips().getOrNull(index)
                            if (clip != null) showClipOptions(clip, this)
                            true
                        }
                    }

                    if (label == "⌫") {
                        val handler = Handler(Looper.getMainLooper())
                        var repeating = false
                        val repeatDelete = object : Runnable {
                            override fun run() {
                                if (!repeating) return
                                deleteOneUnit()
                                handler.postDelayed(this, 75L)
                            }
                        }
                        setOnTouchListener { view, event ->
                            when (event.actionMasked) {
                                MotionEvent.ACTION_DOWN -> {
                                    repeating = true
                                    view.isPressed = true
                                    handleKey("⌫")
                                    handler.postDelayed(repeatDelete, 380L)
                                    true
                                }
                                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                    repeating = false
                                    handler.removeCallbacks(repeatDelete)
                                    view.isPressed = false
                                    true
                                }
                                else -> true
                            }
                        }
                    }
                }
                val weight = when {
                    // In the bottom symbol row (/, *, 0, #, Delete),
                    // Delete must match the neighboring # key exactly.
                    symbols && !extendedSymbols && rowIndex == rows.lastIndex - 1 && label == "⌫" -> 1f
                    // On the Emoji page, Delete must match the width of each emoji key.
                    emojiMode && label == "⌫" -> 1f
                    // In Clipboard, the delete key fills the ninth grid cell
                    // with exactly the same width as each clipboard item.
                    clipMode && !customMode && label == "⌫" -> 1f
                    label in setOf("⇧", "⌫", "?123", "ABC", "Custom", "ALT", "↵", "😊", "🍑", "📋", "🗑", "↩", "🔍") -> 1.2f
                    label == "spasi" -> 2f
                    else -> 1f
                }
                val height = if (rowIndex == rows.lastIndex) 52 else 56
                val lp = LinearLayout.LayoutParams(0, keyboardHeight(height), weight)
                lp.setMargins(dp(2), dp(3), dp(2), dp(3))
                line.addView(button, lp)
            }
            val lineParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            // Custom dan Clipboard memakai baris tetap tanpa area gulir.
            // Jumlah item sudah dibatasi sehingga semua tombol ditampilkan langsung.
            root.addView(line, lineParams)
        }

        // Baris paling bawah permanen: Spasi dan Cari.
        // Tombol Hapus dan Baris Baru berada di kolom paling kanan pada
        // dua baris terakhir area tombol, sehingga posisinya konsisten di semua mode.
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        fun addBottomAction(display: String, action: String, description: String) {
            val button = Button(this).apply {
                text = display
                textSize = 17f
                setTextColor(p.text)
                setTypeface(null, Typeface.BOLD)
                isAllCaps = false
                minWidth = 0
                minimumWidth = 0
                minHeight = 0
                minimumHeight = 0
                stateListAnimator = null
                contentDescription = description
                background = GradientDrawable().apply {
                    val transparency = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .getInt("keyboard_key_transparency", 28).coerceIn(0, 100)
                    val fillAlpha = (255 * (100 - transparency) / 100f).toInt()
                    setColor(Color.argb(fillAlpha, Color.red(p.special), Color.green(p.special), Color.blue(p.special)))
                    cornerRadius = dp(5).toFloat()
                    setStroke(dp(1), Color.argb(110, 0, 0, 0))
                }
                setPadding(dp(4), 0, dp(4), 0)
                setOnClickListener { handleKey(action) }
            }
            val lp = LinearLayout.LayoutParams(0, keyboardHeight(52), 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(2))
            actionRow.addView(button, lp)
        }

        // Tombol navigasi bawah menyesuaikan halaman aktif.
        if (customMode) {
            addBottomAction("?123", "?123", "Kembali ke tombol angka dan simbol")
            addBottomAction("😊", "😊", "Buka halaman Emoji")
        } else {
            addBottomAction("Custom", "Custom", "Buka halaman Keyboard Custom")
            if (emojiMode) {
                addBottomAction("?123", "?123", "Kembali ke tombol angka dan simbol")
            } else {
                if (!clipMode) addBottomAction("📋", "📋", "Riwayat Clipboard")
                addBottomAction("😊", "😊", "Emoji")
            }
        }
        addBottomAction("🔍  Cari", "🔍", "Jalankan pencarian")
        root.addView(actionRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        return root
    }

    private fun keyboardBackground(fallbackColor: Int): android.graphics.drawable.Drawable {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val photoUri = prefs.getString("keyboard_photo_uri", null)
        if (photoUri.isNullOrBlank()) return ColorDrawable(fallbackColor)
        return try {
            val uri = android.net.Uri.parse(photoUri)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
            val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                ?: return ColorDrawable(fallbackColor)
            val photo = BitmapDrawable(resources, bitmap).apply { gravity = Gravity.FILL }
            val darkness = prefs.getInt("keyboard_photo_darkness", 25).coerceIn(0, 100)
            val overlay = ColorDrawable(Color.argb((darkness * 255 / 100), 0, 0, 0))
            LayerDrawable(arrayOf(photo, overlay))
        } catch (_: Exception) {
            ColorDrawable(fallbackColor)
        }
    }

    // Kapitalisasi judul sederhana: huruf pertama setiap kata menjadi besar.
    private fun titleCase(value: String): String {
        // Tokenize words AND whitespace separately so spaces/newlines are preserved.
        return Regex("\\s+|\\S+").findAll(value.lowercase()).joinToString("") { match ->
            val part = match.value
            if (part.isBlank()) part
            else part.replaceFirstChar { char ->
                if (char.isLowerCase()) char.titlecase() else char.toString()
            }
        }
    }

    private fun String.codePointsCompat(): Int = codePointCount(0, length)

    private fun deleteOneUnit() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun handleKey(label: String) {
        val ic: InputConnection = currentInputConnection ?: return
        when (label) {
            "⇧" -> {
                // Jika pengguna sedang menyeleksi teks, Shift mengubah kapitalisasi
                // teks terpilih, bukan mengaktifkan huruf besar untuk ketikan berikutnya.
                val selected = ic.getSelectedText(0)?.toString()
                if (!selected.isNullOrEmpty()) {
                    val upper = selected.uppercase()
                    val lower = selected.lowercase()
                    val title = titleCase(selected)
                    val transformed = when {
                        selected == upper -> title
                        selected == title -> lower
                        else -> upper
                    }
                    ic.commitText(transformed, 1)
                    shifted = false
                    capsLocked = false
                    lastShiftTapMs = 0L
                    setInputView(buildKeyboard())
                    return
                }

                val now = android.os.SystemClock.uptimeMillis()
                if (now - lastShiftTapMs < 400L) {
                    capsLocked = !capsLocked
                    shifted = false
                } else if (capsLocked) {
                    capsLocked = false
                    shifted = false
                } else shifted = true
                lastShiftTapMs = now
                setInputView(buildKeyboard())
            }
            "?123" -> { clipMode = false; customMode = false; symbols = true; extendedSymbols = false; emojiMode = false; setInputView(buildKeyboard()) }
            "Custom" -> { clipMode = true; customMode = true; emojiMode = false; setInputView(buildKeyboard()) }
            "ABC" -> { clipMode = false; customMode = false; symbols = false; extendedSymbols = false; emojiMode = false; setInputView(buildKeyboard()) }
            "ALT" -> { clipMode = false; customMode = false; symbols = true; extendedSymbols = !extendedSymbols; emojiMode = false; setInputView(buildKeyboard()) }
            "😊" -> { emojiMode = true; clipMode = false; customMode = false; setInputView(buildKeyboard()) }
            "🍑" -> currentInputConnection?.commitText("🍑", 1)
            "📋" -> {
                clipMode = true
                customMode = false
                emojiMode = false
                // Capture the currently available clipboard item when opening history too.
                try {
                    val manager = clipboardManager
                    val clip = manager?.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim()
                        if (!text.isNullOrEmpty()) saveClip(text)
                    }
                } catch (_: Exception) { }
                setInputView(buildKeyboard())
            }
            "↩" -> { clipMode = false; customMode = false; setInputView(buildKeyboard()) }
            "🗑" -> {
                // Hapus hanya riwayat biasa; teks yang disematkan tetap tersimpan.
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("clip_history").apply()
                setInputView(buildKeyboard())
            }
            "⌫" -> deleteOneUnit()
            "spasi" -> ic.commitText(" ", 1)
            "🔍" -> {
                // Tombol Cari terpisah: meminta aksi pencarian ke aplikasi.
                ic.performEditorAction(EditorInfo.IME_ACTION_SEARCH)
            }
            "↵" -> {
                // Tombol Baris Baru selalu menyisipkan newline.
                // Tidak menjalankan aksi Search, Done, atau Send.
                ic.commitText("\n", 1)
            }
            else -> {
                if (clipMode && label.startsWith("CUSTOM")) {
                    val index = label.removePrefix("CUSTOM").toIntOrNull() ?: -1
                    val value = customClipboardTexts().getOrNull(index).orEmpty()
                    if (value.isNotBlank()) ic.commitText(value, 1)
                    return
                }
                if (clipMode && label.startsWith("CLIP")) {
                    val index = label.removePrefix("CLIP").toIntOrNull()?.minus(1) ?: -1
                    val clip = readClips().getOrNull(index)
                    if (clip != null) ic.commitText(clip, 1)
                    return
                }
                // Apply Shift/Caps Lock to the actual text inserted, not only the key label.
                val output = if (!symbols && !emojiMode && label.length == 1 && label[0].isLetter() && (shifted || capsLocked)) {
                    label.uppercase()
                } else {
                    label
                }
                ic.commitText(output, 1)
                if (shifted && !capsLocked && !symbols && !emojiMode && label.length == 1 && label[0].isLetter()) {
                    shifted = false
                    setInputView(buildKeyboard())
                }
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
